<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <title>PLASMA DONATE FOR COVID-19</title>
  </head>
  <body>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">

  <div class="container-fluid">
    <a class="navbar-brand" href="#">COVID-19</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="index.php">HOME</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="blood.php">BLOOD DONATE</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="main.php">CONTACT US</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            HOSPITAL NEAR YOU
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">CHOUDHARY HOSPITAL</a></li>
            <li><a class="dropdown-item" href="#">SHARMA HOSPITAL</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">OTHERS</a></li>
          </ul>
        </li>
        
      </ul>
        <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
      <div class=" my-10"style="float:  right"><img src="images/blood2.png" height="800px" width="700px" /></div>
   <div class="container  my-5" style="text-align: left;">
      <h3>Overview</h3>
      <p>Blood donation is a voluntary procedure that can help save the lives of others. There are several types of blood donation. Each type helps meet different medical needs.</p>
      <h4>Whole blood donation</h4>
      <p>This is the most common type of blood donation, during which you donate about a pint (about half a  liter) of whole blood. The blood is then separated into its components — red cells, plasma and sometimes platelets.</p>
     <h4> Apheresis </h4>
         During apheresis, you are hooked up to a machine that can collect and separate blood components,  including red cells, plasma and platelets, and return unused components back to you.

         <h4 class="my-3">Platelet donation (plateletpheresis)</h4> collects only platelets — the cells that help stop bleeding by clumping and forming plugs (clotting) in blood vessels.<br>

         <p class="my-3">Donated platelets are commonly given to people with clotting problems or cancer and people who will have organ transplants or major surgeries.</p>

        <h4 class="my-3">Donated red blood cells </h4> are typically given to people with severe blood loss, such as after an injury or accident, and people with sickle cell anemia.

        <h4 class="my-3"> Plasma donation (plasmapheresis)</h4>collects the liquid portion of the blood (plasma).Plasma helps blood clot and contains antibodies that help fight off infections.<br>

        <p class="my-3">Plasma is commonly given to people in emergency and trauma situations to help stop bleeding.</p>
    </div>  


<footer class="blog-footer">
  <center><p>Stay safe. Stay home &nbsp;<a href="https://getbootstrap.com/">Plasmadonate</a> by <a href="https://twitter.com/mdo">@covid-19</a></p>
  <p>
    <a href="#">Back to top</a>
  </p></center>
</footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    
  </body>
</html>